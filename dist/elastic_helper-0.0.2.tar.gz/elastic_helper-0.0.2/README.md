# ElasticHelper
ElasticHelper is a small class that wraps elasticsearch. Includes functions for indexing, bulk indexing, bulk updating, querying, etc. 